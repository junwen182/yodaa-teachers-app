// Prevent "Option Chooser" drop-down menu from closing when clicked anywhere inside the drop-down
$(".option-chooser-holder .dropdown-menu").click(function (e)
{
    e.stopPropagation();
});

var hi;

// On click, have an Option be selected (replace the current text on the subject-chooser-button)
$(".option-chooser-holder .dropdown-menu .panel-body ul li").click(function(e) {
  
  // replace the current text
  var newOptionText = $(this).text();
  var selectedOptionText = $(this).parents(".dropdown-menu").prev();
  selectedOptionText.html("<span class='dark-p-text'>" + newOptionText  + "</span><i class='fa fa-chevron-down'></i>");

  // close the dropdown
  $(this).parents(".dropdown-menu").css({"display":"none"});
});

$(".option-chooser-holder").click(function() {
  console.log($(this).children(".dropdown-menu").css({"display":"block"}));
});

